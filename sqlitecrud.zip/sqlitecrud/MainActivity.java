package intersoftkk.com.sqlitecrud;

import android.app.Activity;
import android.content.Context;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import intersoftkk.com.sqlitecrud.Adapter.ListAdapter;
import intersoftkk.com.sqlitecrud.DbWrapper.SugarOrmWrapper;
import intersoftkk.com.sqlitecrud.Model.Student;

public class MainActivity extends Activity{
    Context context;

    private static String TAG ="MAIN";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        context = MainActivity.this;
        //init();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        List<Student> studentList = new ArrayList<Student>();
        SugarOrmWrapper ormWrapper = new SugarOrmWrapper();
        try {
            studentList = ormWrapper.getStudentList(2016, 5, 1);
            Log.d(TAG, " Number of studetns " + studentList.size());

        }catch ( SQLiteException ex ){
            Log.e("MAIN", " Exception has encountered " + ex.getMessage());
        }
        if (studentList == null || studentList.isEmpty() ){
            Log.d(TAG, " Need to insert data first ");
            try {

                // First insert data
                ormWrapper.setStudentData();
                studentList = ormWrapper.getStudentList(2016, 5, 1);
                Log.d(TAG, " Number of studetns( first time) " + studentList.size());
            }catch ( SQLiteException ex){
                Log.e(TAG, " Exception has encountered " + ex.getMessage());
            }
        }

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(MainActivity.this);
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.crud_list_view);
        recyclerView.setLayoutManager(linearLayoutManager);
        ListAdapter listAdapter = new ListAdapter(MainActivity.this, studentList);
        recyclerView.setAdapter(listAdapter);
    }
}
