package intersoftkk.com.sqlitecrud.Const;

/**
 * Created by suhasg on 1/31/17.
 */
public class Config {
    public static String dbName = "sbmi.db";

    private static Config ourInstance = new Config();

    public static Config getInstance() {
        return ourInstance;
    }

    private Config() {
    }
}
