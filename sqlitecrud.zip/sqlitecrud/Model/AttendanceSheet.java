package intersoftkk.com.sqlitecrud.Model;

import com.orm.SugarRecord;

/**
 * Created by user on 1/17/2017.
 */
public class AttendanceSheet extends SugarRecord {

    private int classId;
    private int routineId;
    private int periodId;
    private int subjectId;
    private int facultyId;
    private int serverSheetId;
    private String attendanceDate;
    private String absentStudentIds;

    public AttendanceSheet(int classId, int routineId, int periodId, int subjectId,
                           int facultyId , String attendanceDate, String absentStudentIds) {

        this.absentStudentIds = absentStudentIds;
        this.attendanceDate = attendanceDate;
        this.serverSheetId = serverSheetId;
        this.facultyId = facultyId;
        this.subjectId = subjectId;
        this.periodId = periodId;
        this.routineId = routineId;
        this.classId = classId;
    }

    public int getClassId() {
        return classId;
    }

    public void setClassId(int classId) {
        this.classId = classId;
    }

    public int getRoutineId() {
        return routineId;
    }

    public void setRoutineId(int routineId) {
        this.routineId = routineId;
    }

    public int getPeriodId() {
        return periodId;
    }

    public void setPeriodId(int periodId) {
        this.periodId = periodId;
    }

    public int getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(int subjectId) {
        this.subjectId = subjectId;
    }

    public int getFacultyId() {
        return facultyId;
    }

    public void setFacultyId(int facultyId) {
        this.facultyId = facultyId;
    }

    public int getServerSheetId() {
        return serverSheetId;
    }

    public void setServerSheetId(int serverSheetId) {
        this.serverSheetId = serverSheetId;
    }

    public String getAttendanceDate() {
        return attendanceDate;
    }

    public void setAttendanceDate(String attendanceDate) {
        this.attendanceDate = attendanceDate;
    }

    public String getAbsentStudentIds() {
        return absentStudentIds;
    }

    public void setAbsentStudentIds(String absentStudentIds) {
        this.absentStudentIds = absentStudentIds;
    }


}