package intersoftkk.com.sqlitecrud.Model;

import com.orm.SugarRecord;

/**
 * Created by user on 1/12/2017.
 */
public class Student extends SugarRecord{


    private String firstName;
    private String lastName;
    private String gender;
    private Integer classId;
    private Integer sectionId;
    private Integer rollNumber;
    private Integer academicYear;


    public Student(){

    }
    public Student(String firstName, String lastName, String gender,Integer rollNumber,
                   Integer academicYear, Integer classId, Integer sectionId){

        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.rollNumber = rollNumber;
        this.academicYear = academicYear;
        this.classId = classId;
        this.sectionId = sectionId;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Integer getRollNumber() {
        return rollNumber;
    }

    public void setRollNumber(Integer rollNumber) {
        this.rollNumber = rollNumber;
    }

    public Integer getAcademicYear() {
        return academicYear;
    }

    public void setAcademicYear(Integer academicYear) {
        this.academicYear = academicYear;
    }
    public Integer getClassId() {
        return classId;
    }

    public void setClassId(Integer classId) {
        this.classId = classId;
    }

    public Integer getSectionId() {
        return sectionId;
    }

    public void setSectionId(Integer sectionId) {
        this.sectionId = sectionId;
    }

}
