package intersoftkk.com.sqlitecrud.ViewHolder;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;
import intersoftkk.com.sqlitecrud.R;

/**
 * Created by user on 1/12/2017.
 */
public class ListViewHolder extends RecyclerView.ViewHolder {
    private TextView name;
    private TextView roll;

    public ListViewHolder(View itemView){
        super(itemView);
        name = (TextView)itemView.findViewById(R.id.crud_name);
        roll = (TextView)itemView.findViewById(R.id.crud_roll);
    }
    public TextView getName() {
        return name;
    }
    public void setName(TextView name) {
        this.name = name;
    }
    public TextView getRoll() {
        return roll;
    }
    public void setRoll(TextView roll) {
        this.roll = roll;
    }
}
