package intersoftkk.com.sqlitecrud.Adapter;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;

import java.util.List;

import intersoftkk.com.sqlitecrud.Model.Student;
import intersoftkk.com.sqlitecrud.R;
import intersoftkk.com.sqlitecrud.ViewHolder.ListViewHolder;

/**
 * Created by user on 1/12/2017.
 */
public class ListAdapter extends RecyclerView.Adapter<ListViewHolder> {

    private List<Student> studentList;
    private Context context;
    private Button submit;

    public ListAdapter(Context context,List<Student> students){
        this.context = context;
        this.studentList = students;
    }
    @Override
    public ListViewHolder onCreateViewHolder(ViewGroup parent, int viewType)  {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.crud_item,null);
        ListViewHolder listViewHolder = new ListViewHolder(view);
        CheckBox checkBox = (CheckBox)view.findViewById(R.id.crud_checkbox);

        final LinearLayout linearLayout = (LinearLayout)view.findViewById(R.id.crud_row);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (compoundButton.isChecked()){
                    linearLayout.setBackgroundColor(Color.parseColor("#d6f5d6"));
                }
                else
                {
                    linearLayout.setBackgroundColor(Color.parseColor("#ffe5e5"));
                }

            }
        });

        return listViewHolder;
    }
    @Override
    public void onBindViewHolder(ListViewHolder holder, int position) {
        holder.getName().setText(String.format("%s %s", studentList.get(position).getFirstName(),
                studentList.get(position).getLastName()));

        holder.getRoll().setText(String.valueOf( studentList.get(position).getRollNumber()));
    }

    @Override
    public int getItemCount() {
        return this.studentList.size();
    }


}
