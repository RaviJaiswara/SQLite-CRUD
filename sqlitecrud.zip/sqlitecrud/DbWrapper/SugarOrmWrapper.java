package intersoftkk.com.sqlitecrud.DbWrapper;

import android.database.sqlite.SQLiteException;

import com.orm.SugarApp;
import com.orm.query.Condition;
import com.orm.query.Select;

import java.util.ArrayList;
import java.util.List;

import intersoftkk.com.sqlitecrud.Model.AttendanceSheet;
import intersoftkk.com.sqlitecrud.Model.Student;

/**
 * Created by suhasg on 1/31/17.
 */

public class SugarOrmWrapper extends SugarApp{

    private static String LogTag = "ORM";

    @Override
    public final void onCreate() {
        super.onCreate();
    }


    /**
     * Get Student list by class, year
     * @param year
     * @param classId
     * @param sectionId
     * @return ArrayList
     */
    public List<Student> getStudentList(Integer year, Integer classId, Integer sectionId) throws SQLiteException {

        List<Student> students = new ArrayList<Student>();
        students = Select.from(Student.class).where(
                        Condition.prop("academic_Year").eq(year),
                        Condition.prop("class_Id").eq(classId),
                        Condition.prop("section_Id").eq(sectionId))
                        .orderBy("roll_Number")
                        .list();



        return students;
    }

    /**
     * Set Student data
     * @return
     * @throws SQLiteException
     */
    public int setStudentData() throws SQLiteException{
        //String firstName, String lastName, String gender,Integer rollNumber, Integer academicYear){
        Student student = new Student("Ram", "Das","M",10,2016,5,1);
        student.save();

        student = new Student("Barnali", "Kubota","F",13,2016,5,1);
        student.save();

        student = new Student("Rafikul", "Rana","M",45,2016,5,1);
        student.save();

        student = new Student("Mariko", "Shibata","F",34,2016,5,1);
        student.save();

        student = new Student("Asao", "Hiroshi","M",27,2016,5,1);
        student.save();

        return 5;
    }

    /**
     * Save Student attendacne sheet
     * @param attendanceSheet
     * @return
     * @throws SQLiteException
     */
    public int saveAttendanceSheet(AttendanceSheet attendanceSheet) throws  SQLiteException{
        // TODO
        return 1;
    }

    /**
     * Update server id for a sheet
     * @param sheetId
     * @param serverId
     */
    public int updateServerId(int sheetId, int serverId){

        // TODO

        return 1;
    }

}
