package intersoftkk.com.sqlitecrud.WifiConnection;

import android.content.Context;
import android.content.DialogInterface;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import android.support.v7.app.AlertDialog;
import java.util.List;

/**
 * Created by user on 1/19/2017.
 */
public class WifiConnector {
    private String networkSSID = "Intersoft_TP-LINK";
    private String networkPass = "intersoftkk";

    public WifiConnector(final Context context, final WifiManager mainWifi) {

        WifiConfiguration wifiConfiguration = new WifiConfiguration();
        wifiConfiguration.SSID = "\""+networkSSID+"\"";
        wifiConfiguration.wepKeys[0]="\""+networkPass+"\"";
        System.out.println("password is "+networkPass);
        wifiConfiguration.wepTxKeyIndex = 0;
        wifiConfiguration.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
        wifiConfiguration.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP40);
        wifiConfiguration.preSharedKey = "\""+ networkPass +"\"";
        wifiConfiguration.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
        mainWifi.addNetwork(wifiConfiguration);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
        if (mainWifi.isWifiEnabled() == false) {
            alertDialogBuilder.setTitle("Wifi Settings");
            alertDialogBuilder.setMessage("Do you want to enable WIFI ?")
                    .setCancelable(false)
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int id) {
                            //onbhg(mainWifi);
                            mainWifi.setWifiEnabled(true);
                            OnDialog(context);
                            //context.startActivity(new Intent(WifiManager.ACTION_PICK_WIFI_NETWORK));
                            List<WifiConfiguration> list = mainWifi.getConfiguredNetworks();
                            System.out.println("total list is "+list);
                            for (WifiConfiguration i : list){
                                if (i.SSID != null && i.SSID.equals("\""+networkSSID+"\"")){
                                    //mainWifi.disconnect();
                                    mainWifi.enableNetwork(i.networkId,true);
                                    mainWifi.reconnect();
                                    System.out.println("wifi status is :"+mainWifi.reconnect());
                                    break;
                                }
                            }
                        }
                    }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int id) {
                            OffDialog(context);
                        }
                    });
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        } else {
            OnDialog(context);
        }
    }
    private void OffDialog(Context context) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
        alertDialogBuilder.setMessage("Data is saved successfully but not synced");
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }
    private void OnDialog(Context context) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
        RegisterStudent registerStudent = new RegisterStudent(context);
        alertDialogBuilder.setMessage("Data is saved and synced successfully");
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }
}
