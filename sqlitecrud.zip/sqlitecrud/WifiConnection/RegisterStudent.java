package intersoftkk.com.sqlitecrud.WifiConnection;

import android.content.Context;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

/**
 * Created by user on 1/19/2017.
 */
public class RegisterStudent {
    private static final String register_url = "http://54.64.136.160/devel/smart_recruit/attendance.php";

    public RegisterStudent(final Context context) {
        StringRequest stringRequset = new StringRequest(Request.Method.POST, register_url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                //Log.d("Response Data is  ", response);
                Toast.makeText(context, response, Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(context,error.toString(),Toast.LENGTH_SHORT).show();
                        //System.out.println("data connection lost is :"+error.toString());
                    }
                }) {
            /*@Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("classId", "5");
                params.put("routineId", "23");
                params.put("period", "34");
                params.put("subject", "2");
                params.put("facultyId", "45");
                params.put("date", "2017-02-10");
                params.put("absentStudentIds", "10,4,78,23,7");
                return params;*/

        };
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        requestQueue.add(stringRequset);
    }
}

