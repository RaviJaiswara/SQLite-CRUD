package intersoftkk.com.sqlitecrud.Display;

import android.content.Context;
import android.support.v7.app.AlertDialog;

import java.util.ArrayList;
import java.util.List;

import intersoftkk.com.sqlitecrud.DbWrapper.SugarOrmWrapper;
import intersoftkk.com.sqlitecrud.GlobalVariable.GlobalVariable;
import intersoftkk.com.sqlitecrud.Model.Student;

/**
 * Created by user on 2/8/2017.
 */
public class StudentDisplay {
   public List<Student> StudentDisplay(Context context){
        List<Student> studentList = new ArrayList<Student>();
        SugarOrmWrapper sugarOrmWrapper = new SugarOrmWrapper();

        if (GlobalVariable.classPosition == 1 && GlobalVariable.sectionPosition == 0){
             studentList = sugarOrmWrapper.getStudentList(2016,5,1);
        }
        else if (GlobalVariable.classPosition == 1 && GlobalVariable.sectionPosition == 1){
            studentList = sugarOrmWrapper.getStudentList(2016,5,2);
        }
        else if (GlobalVariable.classPosition == 2 && GlobalVariable.sectionPosition == 0){
             studentList = sugarOrmWrapper.getStudentList(2016,6,6);
        }
        else if (GlobalVariable.classPosition == 2 && GlobalVariable.sectionPosition == 1){
             studentList = sugarOrmWrapper.getStudentList(2016,6,7);
        }
        else if (GlobalVariable.classPosition == 3 && GlobalVariable.sectionPosition == 0){
             studentList = sugarOrmWrapper.getStudentList(2016,7,10);
        }
        else if (GlobalVariable.classPosition == 3 && GlobalVariable.sectionPosition == 1){
             studentList = sugarOrmWrapper.getStudentList(2016,7,11);
        }
        else if (GlobalVariable.classPosition == 4 && GlobalVariable.sectionPosition == 0){
             studentList = sugarOrmWrapper.getStudentList(2016,8,21);
        }
        else if (GlobalVariable.classPosition == 4 && GlobalVariable.sectionPosition == 1){
             studentList = sugarOrmWrapper.getStudentList(2016,8,20);
        }
        else if (GlobalVariable.classPosition == 5 && GlobalVariable.sectionPosition == 0){
             studentList = sugarOrmWrapper.getStudentList(2016,9,24);
        }
        else if (GlobalVariable.classPosition == 5 && GlobalVariable.sectionPosition == 1){
             studentList = sugarOrmWrapper.getStudentList(2016,9,23);
        }
        else if (GlobalVariable.classPosition == 5 && GlobalVariable.sectionPosition == 2){
             studentList = sugarOrmWrapper.getStudentList(2016,9,22);
        }
        else if (GlobalVariable.classPosition == 6 && GlobalVariable.sectionPosition == 0){
             studentList = sugarOrmWrapper.getStudentList(2016,10,25);
        }
        else if (GlobalVariable.classPosition == 6 && GlobalVariable.sectionPosition == 1){
             studentList = sugarOrmWrapper.getStudentList(2016,10,26);
        }
        else if (GlobalVariable.classPosition == 7 && GlobalVariable.sectionPosition == 0){
             studentList = sugarOrmWrapper.getStudentList(2016,11,19);
        }
        else if (GlobalVariable.classPosition == 7 && GlobalVariable.sectionPosition == 1){
             studentList = sugarOrmWrapper.getStudentList(2016,11,16);
   }
        else if (GlobalVariable.classPosition == 7 && GlobalVariable.sectionPosition == 2){
             studentList = sugarOrmWrapper.getStudentList(2016,11,14);
        }
        else if (GlobalVariable.classPosition == 8 && GlobalVariable.sectionPosition == 0){
             studentList = sugarOrmWrapper.getStudentList(2016,12,18);
             System.out.println("student is : "+studentList);
        }
        else if (GlobalVariable.classPosition == 8 && GlobalVariable.sectionPosition == 1){
             studentList = sugarOrmWrapper.getStudentList(2016,12,15);
             System.out.println("student is : "+studentList);
        }
        else if (GlobalVariable.classPosition == 8 && GlobalVariable.sectionPosition == 2){
             studentList = sugarOrmWrapper.getStudentList(2016,12,17);
             System.out.println("student is : "+studentList);
        }
        else {
             AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
             alertDialogBuilder.setMessage("Please select class and section of student");
             AlertDialog alertDialog = alertDialogBuilder.create();
             alertDialog.show();
        }
return studentList;
    }
}
