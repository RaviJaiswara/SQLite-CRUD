package intersoftkk.com.sqlitecrud;

import android.content.Context;
import android.content.Intent;
import android.database.SQLException;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

import intersoftkk.com.sqlitecrud.DbWrapper.SugarOrmWrapper;
import intersoftkk.com.sqlitecrud.Display.StudentDisplay;
import intersoftkk.com.sqlitecrud.GlobalVariable.GlobalVariable;

/**
 * Created by user on 2/7/2017.
 */
public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private static String TAG ="MAIN";
    ArrayList<String> classList = new ArrayList<>();
    SugarOrmWrapper ormWrapper = new SugarOrmWrapper();
    ArrayList<String> sectionList = new ArrayList<>();
    StudentDisplay studentDisplay = new StudentDisplay();
    Spinner selectSection;
    Spinner selectClass;
    Context context;
    Button studentSubmit;
    RecyclerView recyclerView;
    LinearLayoutManager linearLayoutManager;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        context = MainActivity.this;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        selectClass = (Spinner) findViewById(R.id.class_select);
        selectSection = (Spinner) findViewById(R.id.section_select);
        studentSubmit = (Button) findViewById(R.id.student_submit);

        /*recyclerView = (RecyclerView) findViewById(R.id.student_list_view);
        linearLayoutManager = new LinearLayoutManager(MainActivity.this);
        recyclerView.setLayoutManager(linearLayoutManager);*/

        if (ormWrapper.getStudentList(2016, 5, 1) == null || ormWrapper.getStudentList(2016, 5, 1).isEmpty()) {
            {
                try {
                    Log.d(TAG, "Need to insert data first");
                    ormWrapper.setStudentData();
                } catch (SQLException e) {
                    e.getMessage();
                }
            }
        }
        if (ormWrapper.getId(2016) == null || ormWrapper.getId(2016).isEmpty()) {

            try {
                Log.d(TAG, "Need to insert data first");
                ormWrapper.setId();
            } catch (SQLException ex) {
                ex.getMessage();
            }
        }
        selectClass.setOnItemSelectedListener(this);
        if (classList != null) {
            classList.clear();
        }
        classList.add("Select Class");
        classList.add("Class 5(V)");
        classList.add("Class 6(VI)");
        classList.add("Class 7(VII)");
        classList.add("Class 8(VIII)");
        classList.add("Class 9(IX)");
        classList.add("Class 10(X)");
        classList.add("Class 11(XI)");
        classList.add("Class 12(XII)");

        final ArrayAdapter<String> classAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, classList);
        classAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        selectClass.setAdapter(classAdapter);

        studentSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, StudentData.class);
                startActivity(intent);
                /*if(studentDisplay.StudentDisplay(context).size()>0)
                {
                    StudentListAdapter studentListAdapter = new StudentListAdapter(MainActivity.this,studentDisplay.StudentDisplay(context));
                        recyclerView.setAdapter(studentListAdapter);

                }
                else
                {
                    StudentInsertServer insertStudent = new StudentInsertServer(context, ormWrapper.getId(2016).get(GlobalVariable.classPosition).getClassId(),ormWrapper.getId(2016).get(GlobalVariable.sectionPosition).getSectionId());
                    System.out.println("data is :" +insertStudent);
                    try {
                        StudentJson studentJson = new StudentJson(ormWrapper.getId(2016).get(GlobalVariable.classPosition).getClassId(),ormWrapper.getId(2016).get(GlobalVariable.sectionPosition).getSectionId(),context);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }*/
            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Spinner studentClass = (Spinner) parent;
        Spinner studentSection = (Spinner) parent;
        if (studentClass.getId() == R.id.class_select) {
            Toast.makeText(this, "Your choose :" + position, Toast.LENGTH_SHORT).show();
            GlobalVariable.classPosition = position;
            this.sectionList.clear();
            SectionSelection();
        }
        if (studentSection.getId() == R.id.section_select) {
            Toast.makeText(this, "Your choose :" + position, Toast.LENGTH_SHORT).show();
            GlobalVariable.sectionPosition = position;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        Toast.makeText(this, "Choose :", Toast.LENGTH_SHORT).show();
    }

    private void SectionSelection() {
        selectSection.setOnItemSelectedListener(this);
        if (GlobalVariable.classPosition == 0) {
            Toast.makeText(this, "Please select Student Class", Toast.LENGTH_SHORT).show();
        }
        if (GlobalVariable.classPosition == 1) {
            sectionList.add(ormWrapper.getId(2016).get(1).getSectionText());
            sectionList.add(ormWrapper.getId(2016).get(2).getSectionText());
        } else if (GlobalVariable.classPosition == 2) {
            sectionList.add(ormWrapper.getId(2016).get(3).getSectionText());
            sectionList.add(ormWrapper.getId(2016).get(4).getSectionText());
        }
        if (GlobalVariable.classPosition == 3) {
            sectionList.add(ormWrapper.getId(2016).get(5).getSectionText());
            sectionList.add(ormWrapper.getId(2016).get(6).getSectionText());
        }
        if (GlobalVariable.classPosition == 4) {
            sectionList.add(ormWrapper.getId(2016).get(7).getSectionText());
            sectionList.add(ormWrapper.getId(2016).get(8).getSectionText());
        }
        if (GlobalVariable.classPosition == 5) {
            sectionList.add(ormWrapper.getId(2016).get(9).getSectionText());
            sectionList.add(ormWrapper.getId(2016).get(10).getSectionText());
            sectionList.add(ormWrapper.getId(2016).get(11).getSectionText());
        }
        if (GlobalVariable.classPosition == 6) {
            sectionList.add(ormWrapper.getId(2016).get(12).getSectionText());
            sectionList.add(ormWrapper.getId(2016).get(13).getSectionText());
        }
        if (GlobalVariable.classPosition == 7) {
            sectionList.add(ormWrapper.getId(2016).get(14).getSectionText());
            sectionList.add(ormWrapper.getId(2016).get(15).getSectionText());
            sectionList.add(ormWrapper.getId(2016).get(16).getSectionText());
        }
        if (GlobalVariable.classPosition == 8) {
            sectionList.add(ormWrapper.getId(2016).get(17).getSectionText());
            sectionList.add(ormWrapper.getId(2016).get(18).getSectionText());
            sectionList.add(ormWrapper.getId(2016).get(19).getSectionText());
        }
        ArrayAdapter<String> sectionAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, sectionList);
        sectionAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        selectSection.setAdapter(sectionAdapter);
    }
}
