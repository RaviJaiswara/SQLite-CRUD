package intersoftkk.com.sqlitecrud.Json;

import android.app.AlertDialog;
import android.content.Context;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import intersoftkk.com.sqlitecrud.DbWrapper.SugarOrmWrapper;

/**
 * Created by user on 2/13/2017.
 */
public class StudentJson {

    public StudentJson(int classId, int section, final Context context) throws IOException {
        final String url = "http://54.248.218.27/api/students/search?class=" + classId + "&section=" + section;
        final JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONObject result = response.getJSONObject("results");
                            JSONArray students = result.getJSONArray("students");
                            for (int i = 0; i<students.length(); i++){
                                JSONObject jsonObject = students.getJSONObject(i);
                                String firstName = jsonObject.optString("first_name");
                                String lastName = jsonObject.optString("last_name");
                                String gender = jsonObject.optString("gender");
                                int rollNumber = Integer.parseInt(jsonObject.optString("roll_number"));
                                int year = Integer.parseInt(jsonObject.optString("academic_year"));
                                int classId = Integer.parseInt(jsonObject.optString("class_id"));
                                int sectionId = Integer.parseInt(jsonObject.optString("section_id"));
                                System.out.println("data is " +firstName.toString());

                                SugarOrmWrapper.InsertStudent(firstName,lastName,gender,rollNumber,year,classId,sectionId);
                            }
                            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
                            alertDialogBuilder.setMessage("Data is Inserted Successfully");
                            AlertDialog alertDialog = alertDialogBuilder.create();
                            alertDialog.show();


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        Volley.newRequestQueue(context).add(jsonObjectRequest);
    }
}
