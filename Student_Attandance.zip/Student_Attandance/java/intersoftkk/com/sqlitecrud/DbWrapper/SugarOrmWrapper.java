package intersoftkk.com.sqlitecrud.DbWrapper;

import android.database.SQLException;
import android.database.sqlite.SQLiteException;

import com.orm.SugarApp;
import com.orm.query.Condition;
import com.orm.query.Select;

import java.util.ArrayList;
import java.util.List;

import intersoftkk.com.sqlitecrud.Model.AttendanceSheet;
import intersoftkk.com.sqlitecrud.Model.Student;
import intersoftkk.com.sqlitecrud.Model.ClassSection;

/**
 * Created by suhasg on 1/31/17.
 */

public class SugarOrmWrapper extends SugarApp{

    private static String LogTag = "ORM";

    @Override
    public final void onCreate() {
        super.onCreate();
    }
    /**
     * Get Student list by class, year
     * @param year
     * @param classId
     * @param sectionId
     * @return ArrayList
     */
    public List<Student> getStudentList(Integer year, Integer classId, Integer sectionId) throws SQLiteException {

        List<Student> students = new ArrayList<Student>();
        students = Select.from(Student.class).where(
                        Condition.prop("academic_Year").eq(year),
                        Condition.prop("class_Id").eq(classId),
                        Condition.prop("section_Id").eq(sectionId))
                        .orderBy("roll_Number")
                        .list();
        return students;
    }
    public List<ClassSection>getId(Integer year) throws SQLException{
        List<ClassSection> studentAttendanceSheets = new ArrayList<ClassSection>();
        studentAttendanceSheets = Select.from(ClassSection.class).where(
                Condition.prop("year").eq(year))
                .list();
        return studentAttendanceSheets;
    }
   public static int InsertStudent(String firstname, String lastName, String gender, int rollNumber, int year, int classId, int sectionId) throws SQLException{
       Student student = new Student(firstname,lastName,gender,rollNumber,year,classId,sectionId);
       student.save();
       return 0;
   }
    /**
     * Set Student data
     * @return
     * @throws SQLiteException
     */
    public int setStudentData() throws SQLiteException{
        //String firstName, String lastName, String gender,Integer rollNumber, Integer academicYear){
        Student student = new Student("Abhishek", "Halder","M",1,2016,5,1);
        student.save();

        student = new Student("Suhas", "Ghosh","M",2,2016,5,1);
        student.save();

        student = new Student("Ronit", "Chokroborty","M",3,2016,5,1);
        student.save();

        student = new Student("Sayantan", "Kundu","M",4,2016,5,1);
        student.save();

        student = new Student("Ananda", "Sarkar","M",5,2016,5,1);
        student.save();

        student = new Student("Sameer", "Patra","M",6,2016,5,1);
        student.save();

        student = new Student("Mousumi", "Dhar","F",7,2016,5,1);
        student.save();

        student = new Student("Snehasis", "Das","M",8,2016,5,1);
        student.save();

        student = new Student("Arnab", "Sarkar","M",9,2016,5,1);
        student.save();

        student = new Student("Sanjib", "Mukherjee","M",10,2016,5,1);
        student.save();

        student = new Student("Ritesh", "Chandra","M",11,2016,5,1);
        student.save();

        student = new Student("Sourabh", "Ganguly","M",12,2016,5,1);
        student.save();

        student = new Student("Tapas", "Pal","M",13,2016,5,1);
        student.save();

        student = new Student("Soumitra", "Mukherjee","F",14,2016,5,1);
        student.save();

        student = new Student("Ashish", "Kole","M",15,2016,5,1);
        student.save();

        student = new Student("Arijit", "Bera","M",16,2016,5,1);
        student.save();

        student = new Student("Samit", "Saha","M",17,2016,5,1);
        student.save();

        student = new Student("Anup", "Kumar","M",18,2016,5,1);
        student.save();

        student = new Student("Prodatree", "Mukherjee","F",19,2016,5,1);
        student.save();

        student = new Student("Suman", "Sarkar","M",20,2016,5,1);
        student.save();


        return 20;
    }
    public  int setId() throws SQLException{
        ClassSection studentAttendanceSheet = new ClassSection(5,1,"Student Class","Student Section",2016);
        studentAttendanceSheet.save();

        studentAttendanceSheet = new ClassSection(5,1,"V","A",2016);
        studentAttendanceSheet.save();

        studentAttendanceSheet = new ClassSection(5,2,"V","B",2016);
        studentAttendanceSheet.save();

        studentAttendanceSheet = new ClassSection(6,6,"VI","A",2016);
        studentAttendanceSheet.save();

        studentAttendanceSheet = new ClassSection(6,7,"VI","B",2016);
        studentAttendanceSheet.save();

        studentAttendanceSheet = new ClassSection(7,10,"VII","A",2016);
        studentAttendanceSheet.save();

        studentAttendanceSheet = new ClassSection(7,11,"VII","B",2016);
        studentAttendanceSheet.save();

        studentAttendanceSheet = new ClassSection(8,21,"VIII","B",2016);
        studentAttendanceSheet.save();

        studentAttendanceSheet = new ClassSection(8,20,"VIII","A",2016);
        studentAttendanceSheet.save();

        studentAttendanceSheet = new ClassSection(9,24,"IX","C",2016);
        studentAttendanceSheet.save();

        studentAttendanceSheet = new ClassSection(9,23,"IX","B",2016);
        studentAttendanceSheet.save();

        studentAttendanceSheet = new ClassSection(9,22,"VIX","A",2016);
        studentAttendanceSheet.save();

        studentAttendanceSheet = new ClassSection(10,25,"X","A",2016);
        studentAttendanceSheet.save();

        studentAttendanceSheet = new ClassSection(10,26,"X","B",2016);
        studentAttendanceSheet.save();

        studentAttendanceSheet = new ClassSection(11,19,"XI","txt_commerce",2016);
        studentAttendanceSheet.save();

        studentAttendanceSheet = new ClassSection(11,16,"XI","txt_science",2016);
        studentAttendanceSheet.save();

        studentAttendanceSheet = new ClassSection(11,14,"XI","txt_arts",2016);
        studentAttendanceSheet.save();

        studentAttendanceSheet = new ClassSection(12,18,"XII","txt_commerce",2016);
        studentAttendanceSheet.save();

        studentAttendanceSheet = new ClassSection(12,15,"XII","txt_arts",2016);
        studentAttendanceSheet.save();

        studentAttendanceSheet = new ClassSection(12,17,"XII","txt_science",2016);
        studentAttendanceSheet.save();

        return 0;
    }

    /**
     * Save Student attendacne sheet
     * @param attendanceSheet
     * @return
     * @throws SQLiteException
     */
    public int saveAttendanceSheet(AttendanceSheet attendanceSheet) throws  SQLiteException{
        // TODO
        return 1;
    }

    /**
     * Update server id for a sheet
     * @param sheetId
     * @param serverId
     */
    public int updateServerId(int sheetId, int serverId){

        // TODO

        return 1;
    }

}
