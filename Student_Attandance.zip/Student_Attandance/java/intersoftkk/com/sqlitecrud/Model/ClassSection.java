package intersoftkk.com.sqlitecrud.Model;

import com.orm.SugarRecord;

/**
 * Created by user on 1/17/2017.
 */
public class ClassSection extends SugarRecord {

    private int classId;
    private int sectionId;
    private String classText;
    private String sectionText;
    private int year;

    public ClassSection(){

    }

    public ClassSection(int classId, int sectionId, String classText, String sectionText, Integer year) {
        this.sectionText = sectionText;
        this.classText = classText;
        this.sectionId = sectionId;
        this.classId = classId;
        this.year = year;

    }




    public int getClassId() {
        return classId;
    }

    public void setClassId(int classId) {
        this.classId = classId;
    }

    public int getSectionId() {
        return sectionId;
    }

    public void setSectionId(int sectionId) {
        this.sectionId = sectionId;
    }

    public String getClassText() {
        return classText;
    }

    public void setClassText(String classText) {
        this.classText = classText;
    }

    public String getSectionText() {
        return sectionText;
    }

    public void setSectionText(String sectionText) {
        this.sectionText = sectionText;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
}