package intersoftkk.com.sqlitecrud.GlobalVariable;

/**
 * Created by user on 2/7/2017.
 */
public class GlobalVariable {

    public static int classPosition = 0;
    public static int sectionPosition = 0;
}
