package intersoftkk.com.sqlitecrud.Adapter;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;

import java.util.List;

import intersoftkk.com.sqlitecrud.Model.Student;
import intersoftkk.com.sqlitecrud.R;
import intersoftkk.com.sqlitecrud.ViewHolder.StudentListViewHolder;

/**
 * Created by user on 2/9/2017.
 */
public class StudentListAdapter extends RecyclerView.Adapter<StudentListViewHolder> {
    private List<Student> studentLists;
    Context context;
    public StudentListAdapter(Context context, List<Student> studentLists){
        this.context = context;
        this.studentLists = studentLists;
    }

    @Override
    public StudentListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.student_list,null);
        CheckBox checkBox = (CheckBox)view.findViewById(R.id.student_checkbox);
        final LinearLayout linearLayout = (LinearLayout)view.findViewById(R.id.student_row);
        StudentListViewHolder studentListViewHolder = new StudentListViewHolder(view);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (compoundButton.isChecked()){
                    linearLayout.setBackgroundColor(Color.parseColor("#d6f5d6"));
                }
                else
                {
                    linearLayout.setBackgroundColor(Color.parseColor("#ffe5e5"));
                }

            }
        });
        return studentListViewHolder;
    }

    @Override
    public void onBindViewHolder(StudentListViewHolder holder, int position) {
        holder.getName().setText(String.format("%s %s", studentLists.get(position).getFirstName(),studentLists.get(position).getLastName()));
        holder.getRoll().setText(String.valueOf(studentLists.get(position).getRollNumber()));
    }

    @Override
    public int getItemCount() {
        return this.studentLists.size();
    }
}
