package intersoftkk.com.sqlitecrud;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Button;

import java.io.IOException;

import intersoftkk.com.sqlitecrud.Adapter.StudentListAdapter;
import intersoftkk.com.sqlitecrud.DbWrapper.SugarOrmWrapper;
import intersoftkk.com.sqlitecrud.Display.StudentDisplay;
import intersoftkk.com.sqlitecrud.GlobalVariable.GlobalVariable;
import intersoftkk.com.sqlitecrud.Json.StudentJson;
import intersoftkk.com.sqlitecrud.RegisterStudent.StudentInsertServer;

public class StudentData extends Activity{
    Context context;
    Button submit;
    RecyclerView recyclerView;
    LinearLayoutManager linearLayoutManager;
    StudentDisplay studentDisplay = new StudentDisplay();
    SugarOrmWrapper ormWrapper = new SugarOrmWrapper();
    /*private static String TAG ="MAIN";*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        context = StudentData.this;


        //init();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.student_data_list);
        submit = (Button)findViewById(R.id.crud_button);
        recyclerView = (RecyclerView) findViewById(R.id.student_list_view);
        linearLayoutManager = new LinearLayoutManager(StudentData.this);
        recyclerView.setLayoutManager(linearLayoutManager);
        if(studentDisplay.StudentDisplay(context).size()>0)
        {
            StudentListAdapter studentListAdapter = new StudentListAdapter(StudentData.this,studentDisplay.StudentDisplay(context));
            recyclerView.setAdapter(studentListAdapter);

        }
        else
        {
            StudentInsertServer insertStudent = new StudentInsertServer(context, ormWrapper.getId(2016).get(GlobalVariable.classPosition).getClassId(),ormWrapper.getId(2016).get(GlobalVariable.sectionPosition).getSectionId());
            System.out.println("data is :" +insertStudent);
            try {
                StudentJson studentJson = new StudentJson(ormWrapper.getId(2016).get(GlobalVariable.classPosition).getClassId(),ormWrapper.getId(2016).get(GlobalVariable.sectionPosition).getSectionId(),context);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}
