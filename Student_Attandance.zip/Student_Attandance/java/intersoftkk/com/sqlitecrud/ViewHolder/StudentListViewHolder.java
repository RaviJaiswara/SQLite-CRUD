package intersoftkk.com.sqlitecrud.ViewHolder;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import intersoftkk.com.sqlitecrud.R;

/**
 * Created by user on 2/9/2017.
 */
public class StudentListViewHolder extends RecyclerView.ViewHolder {
    private TextView name;
    private TextView roll;

    public StudentListViewHolder(View view){
        super(view);
        name = (TextView)view.findViewById(R.id.student_name);
        roll = (TextView)view.findViewById(R.id.student_roll);
    }

    public TextView getName() {
        return name;
    }

    public void setName(TextView name) {
        this.name = name;
    }

    public TextView getRoll() {
        return roll;
    }

    public void setRoll(TextView roll) {
        this.roll = roll;
    }
}
