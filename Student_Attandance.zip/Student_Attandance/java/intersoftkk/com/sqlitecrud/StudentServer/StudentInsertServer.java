package intersoftkk.com.sqlitecrud.RegisterStudent;

import android.app.AlertDialog;
import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

/**
 * Created by user on 2/10/2017.
 */
public class StudentInsertServer {

    public StudentInsertServer(final Context context, int classId, int section) {
         final String register_url = "http://54.248.218.27/api/students/search?class="+classId+"&section="+section;

        StringRequest stringRequset = new StringRequest(Request.Method.GET, register_url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.d("Response Data is  ", response);
                Log.d("url is : ", register_url);
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
                alertDialogBuilder.setMessage(""+register_url);
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
                Toast.makeText(context, register_url, Toast.LENGTH_SHORT).show();
                Toast.makeText(context, response, Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context,error.toString(),Toast.LENGTH_SHORT).show();

            }
        }) {

        };
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        requestQueue.add(stringRequset);
    }
}
